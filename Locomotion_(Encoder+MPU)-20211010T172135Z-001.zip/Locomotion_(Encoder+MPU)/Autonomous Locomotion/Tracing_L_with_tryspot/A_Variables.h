/*  Authors          : Shivangi
 *  Date             : 24/12/19
 *  FileName         : A_Variables.h
 */
#ifndef _A_Variables_H_
#define _A_Variables_H_

/***************************************************************************************************************************/
/********************************************* Start of Common Variables ***************************************************/
/***************************************************************************************************************************/

/********** Direction pins **********/
#define dir1 34                                                                           //Direction pin for motor1
#define dir3 30                                                                           //Direction pin for motor3
#define dir2 28                                                                           //Direction pin for motor2
/********** Direction pins **********/

/************* PWM pins *************/
#define pwm1 9                                                                            //PWM pin for motor1
#define pwm3 7                                                                            //PWM pin for motor3
#define pwm2 6                                                                            //PWM pin for motor2
/************* PWM pins *************/

/************ PWM Values ************/
#define Maxpwm 150.00
<<<<<<< HEAD:Example-3W_Auto_Motion/A_Variables.h
int a_basePwm;
=======
int a_basePwm; 
>>>>>>> 9afa6e2433dede7e2185fa37b9d4d8b9d3a483e5:Example_2W_Auto_motion/A_Variables.h
int pwmm1, pwmm2, pwmm3;
/************ PWM Values ************/

/********* Values of Yaw from MPU6050 *********/
int8_t yaw = 0;                                                                           // yaw values from MPU6050 using Serial Communications
int Yaw = 0;                                                                              //Variable to store the resolved value of yaw from -180 to 180
float Yaw_ref = 0;
/********* Values of Yaw from MPU6050 *********/

/***************************************************************************************************************************/
/********************************************** End of Common Variables ****************************************************/
/***************************************************************************************************************************/

/*****************************************************************************************************************************************/
/********************************************* Start of Variables From A_2W_Loc.h File ***************************************************/
/*****************************************************************************************************************************************/

/******* Variables for the encoder *******/
volatile int encodervalue1, encodervalue2;                                                // Count of pulses from encoder 1 and encoder 2
volatile int a, b, c, d;
/******* Variables for the encoder *******/

/************ Encoder Pins ************/
#define encoderPin1 2                                                                     //Interupt pin (A channel) for encoder1
#define encoderPin2 21                                                                    //Interrupt pin (A channel) for encoder2
#define comparePinA 50                                                                    // comparepin B channel for encoder1
#define comparePinB 52                                                                    //comparepin B channel for encoder2
/************ Encoder Pins ************/

/*** A_Forward() Function Variables ***/

float a_kp_dist_forward;                                                                  //Kp is given in proportion to the maxpwm and max error possible
float a_kp_encoder_forward;                                                               //Proportionality constant for the lateral error
float a_ki_dist_forward;                                                                  //Ki for distance
float a_kp_strm2_forward;                                                                 //Proportionality constant for the angular error for motor 2
float a_kp_strm3_forward;                                                                 //Proportionality constant for the angular error for motor 3

float a_error_forward;                                                                    //Variable to store the value of the MPU as error
float a_error_encoder_forward;                                                            //Lateral shift error in forward direction
float a_pwm_encoder_forward;                                                              //PWM due to lateral shift in forward direction
float a_error_sum_forward;                                                                //Adding previous errors for implementing Ki                                                                           
float a_current_forward, a_errorDist_forward;                                               //Current values of encoder and distance error in forward direction.                                                
float a_distanceCovered_forward;                                                          //Distance Covered in forward
float a_requiredDistance_forward;                                                         //Desired distance in forward 

/*** A_Forward() Function Variables ***/

/*** A_Backward() Function Variables ***/

float a_kp_dist_back;                                                                     //Kp is given in proportion to the maxpwm and max error possible
float a_ki_dist_back;                                                                     //Ki for distance
float a_kp_strm2_back;                                                                    //Proportionality constant for the angular error for motor 2
float a_kp_strm3_back;                                                                    //Proportionality constant for the angular error for motor 3

float a_error_back;                                                                         //Variable to store the value of the MPU as error.
float a_error_encoder_back;                                                                 //Lateral shift error in back direction
float a_pwm_encoder_back;                                                                   //PWM due to lateral shift in back direction
float a_error_sum_back;                                                                     //Adding previous errors for implementing Ki                                             
float a_current_back, a_errorDist_back;                                                       //Current values of encoder and distance error in back direction.
float a_distanceCovered_back;                                                               //Distance Covered in back
float a_requiredDistance_back;                                                              //Desired distance in back

/*** A_Backward() Function Variables ***/

/*****************************************************************************************************************************************/
/********************************************** End of Variables From A_2W_Loc.h File ****************************************************/
/*****************************************************************************************************************************************/

/*****************************************************************************************************************************************/
/********************************************* Start of Variables From A_3W_Loc.h File ***************************************************/
/*****************************************************************************************************************************************/

/***** A_Left() Function Variables *****/
float a_kp_dist_left;
float a_kp_encoder_left;                                                                    //Kp is given in proportion to the maxpwm and max error possible
float a_kp_strm1_left;                                                                      //Proportionality constant for the angular error for motor 1
float a_kp_strm2_left;                                                                      //Proportionality constant for the angular error for motor 2
float a_kp_strm3_left;                                                                      //Proportionality constant for the angular error for motor 3
float a_ki_dist_left;                                                                       //Ki for distance

<<<<<<< HEAD:Example-3W_Auto_Motion/A_Variables.h
float a_errorDist_left;
float a_error_left;
float a_current_left, errorDist_left;                                                       //Current values of encoder and distance error in left direction. 
=======
float a_current_left, a_errorDist_left;                                                       //Current values of encoder and distance error in left direction. 
>>>>>>> 9afa6e2433dede7e2185fa37b9d4d8b9d3a483e5:Example_2W_Auto_motion/A_Variables.h
float a_distanceCovered_left;                                                               //Distance Covered in left
float a_requiredDistance_left;                                                              //Desired distance in left
float a_error_encoder_left;                                                                 //Lateral shift error in left direction
float a_pwm_encoder_left;                                                                   //PWM due to lateral shift in left direction
float a_error_sum_left;                                                                     //Adding previous errors for implementing Ki


/***** A_Left() Function Variables *****/

/***** A_Right() Function Variables *****/

float a_error_right;                                                                        //Variable to store the value of the MPU as error.
float a_kp_dist_right;
float a_kp_encoder_right;                                                                   //Kp is given in proportion to the maxpwm and max error possible
float a_kp_strm1_right;                                                                     //Proportionality constant for the angular error for motor 1
float a_kp_strm2_right;                                                                     //Proportionality constant for the angular error for motor 2
float a_kp_strm3_right;                                                                     //Proportionality constant for the angular error for motor 3
float a_ki_dist_right;                                                                      //Ki for distance

<<<<<<< HEAD:Example-3W_Auto_Motion/A_Variables.h
float  a_errorDist_right;
float a_current_right, errorDist_right;                                                     //Current values of encoder and distance error in right direction. 
=======
float a_current_right, a_errorDist_right;                                                     //Current values of encoder and distance error in right direction. 
>>>>>>> 9afa6e2433dede7e2185fa37b9d4d8b9d3a483e5:Example_2W_Auto_motion/A_Variables.h
float a_distanceCovered_right;                                                              //Distance Covered in right
float a_requiredDistance_right;                                                             //Desired distance in right
float a_error_encoder_right;                                                                //Lateral shift error in right direction
float a_pwm_encoder_right;                                                                  //PWM due to lateral shift in right direction
float a_error_sum_right;                                                                    //Adding previous errors for implementing Ki

/***** A_Right() Function Variables *****/

/*****************************************************************************************************************************************/
/********************************************** End of Variables From A_3W_Loc.h File ****************************************************/
/*****************************************************************************************************************************************/

/*********************************************************************************************************************************************/
/********************************************* Start of Variables From A_Orient_Loc.h File ***************************************************/
/*********************************************************************************************************************************************/

//Boolean Variables to set direction of Wheels
bool a_dirW1;
bool a_dirW2;
bool a_dirW3;

//PWM Given to motors for rotating
float a_pwmm_ori;

//PWM Values given to each wheel
int a_pwmm_ori1, a_pwmm_ori2, a_pwmm_ori3;

//Variables used for PID
float a_req_angle = 0.0;
float a_error_ang = 3;

//Variables required to keep track of future and past
float a_rate_change = 5;
float a_error_sum_ori;
float a_prev_error = 0;

//PID Constants
float a_kp_ori;                                                                     //Proportionality constant for orientation
float a_ki_ang;                                                                    //Integral constant for orientation 

/*********************************************************************************************************************************************/
/********************************************** End of Variables From A_Orient_Loc.h File ****************************************************/
/*********************************************************************************************************************************************/
<<<<<<< HEAD:Example-3W_Auto_Motion/A_Variables.h
=======

>>>>>>> 9afa6e2433dede7e2185fa37b9d4d8b9d3a483e5:Example_2W_Auto_motion/A_Variables.h
#endif
