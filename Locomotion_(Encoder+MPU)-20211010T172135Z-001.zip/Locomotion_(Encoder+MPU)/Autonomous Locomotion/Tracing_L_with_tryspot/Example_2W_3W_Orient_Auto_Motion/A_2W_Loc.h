/*  Authors             : Shivangi
 *  Date                : 25/12/19
 *  FileName            : A_2W_Loc.h
 *  Function Names      : updateEncoder1(), updateEncoder2(), A_Forward(), A_Backward()
 */
#ifndef _A_2W_Loc_H_
#define _A_2W_Loc_H_

#include "A_Variables.h"

/*
 *  Function Name       : updateEncoder1()
 *  Input               : No input required
 *  Output              : pulses of the x encoder stored in variable encodervalue1
 *  Logic               : The function will be called when the interrupt is triggered at the rising edge of channel A.
 *                        If the channel B is in phase with the channel A the count is incremented and decremented otherwise
 *  Example Call        : The function is called by the interrupt
 */
void updateEncoder1()
{
    a = digitalRead(encoderPin1);
    b = digitalRead(comparePinB);

    if (b == 1)
        encodervalue1++;
    if (b == 0)
        encodervalue1--;
}

/*
 *  Function Name       : updateEncoder2()
 *  Input               : No input required
 *  Output              : pulses of the y encder stored in variable encodervalue2
 *  Logic               : The function will be called when the interrupt is triggered at the rising edge of channel A.
 *                        If the channel B is in phase with the channel A the count is incremented and decremented otherwise
 *  Example Call        : The function is called by the interrupt
 */
void updateEncoder2()
{
    c = digitalRead(comparePinA);
    d = digitalRead(encoderPin2);

    if (c == 1)
        encodervalue2++;
    if (c == 0)
        encodervalue2--;
}

/*
   Function Name:A_Forward()
   Input:  Required distance(a_requiredDistance_forward) for which function is to be executed,Proportionality constants of Each Motors(a_kp_strm1_forward,a_kp_strm2_forward,a_kp_strm3_forward),
           Encoders(a_kp_encoder_forward) and Distance constant(a_kp_dist_forward,a_ki_dist_forward)
   Output: Motor 2 and 3 will move with same pwm and Motor 1 will have zero PWM. Bot will move in A_Forward Direction(along Motor 1).
   Logic: By giving same PWM to Motors 2 and 3 and Motor 1 will have zero PWM,the bot will move in A_Forward direction. MPU and two XY Encoders are used for FEEDBACK of System.
          PID is implemented for precise movement.
   Example Call:A_Forward(200, a_kp_strm1_forward, a_kp_strm2_forward, a_kp_strm3_forward, a_kp_dist_forward, a_kp_encoder_forward, a_ki_dist_forward);
*/
void A_Forward(float a_requiredDistance_forward, float a_kp_strm2_forward, float a_kp_strm3_forward, float a_kp_dist_forward, float a_kp_encoder_forward, float a_ki_dist_forward)
{
  encodervalue1 = 0;                                                                      //Shifting the origin by initializing both the encoder values to zero
  encodervalue2 = 0;                    
  while (a_distanceCovered_forward < a_requiredDistance_forward)                          //Execute the function till required distance is not reached
  {                    
    if (Serial3.available())                                                              //If data is available on the serial bus
    {                    
      yaw = Serial3.read();                                                               //Read the data on the serial bus and store it in the variable yaw
    }                    
    Yaw = yaw * 2;                                                                        //Convert the range of yaw from -90 to 90 to -180 to 180
                
    a_error_forward = Yaw - Yaw_ref;                                                      //Calculate the angular shift of the bot. Yaw_ref is the reference yaw value from the previous function 

    a_current_forward = abs(encodervalue1);                                                 //Storing the value of the y encoder                                                                                    
    a_distanceCovered_forward = a_current_forward * 0.05026;                                //Multiplying the value of the encoder by the circumference of the dummy wheel              
    a_errorDist_forward = a_requiredDistance_forward - a_distanceCovered_forward;         //Calculating the error in distance                                                             
    a_error_sum_forward = a_errorDist_forward + a_error_sum_forward;                      //Calculating the sum of the errors                                                 
    a_basePwm = abs(a_errorDist_forward) * a_kp_dist_forward;                             //Calculating the basepwm in proportion with the error                               

    a_error_encoder_forward = encodervalue2;                                              //Error for locomotion in y direction is given by the x encoder 
    a_pwm_encoder_forward = a_kp_encoder_forward * (a_error_encoder_forward);             //Calculating the pwm error                                             

    pwmm2 = a_basePwm  + a_kp_strm2_forward * (a_error_forward) - a_pwm_encoder_forward + 12 ;    //Calculating the pwm for motor 2 according to the equations of velocities
    pwmm3 = a_basePwm  - a_kp_strm3_forward * (a_error_forward) + a_pwm_encoder_forward ;         //Calculating the pwm for motor 3 according to the equations of velocities  

    pwmm2 = pwmm2 + a_ki_dist_forward * (a_error_sum_forward);
    pwmm3 = pwmm3 + a_ki_dist_forward * (a_error_sum_forward);

    if(a_error_forward < 15)
    {
      pwmm3 = pwmm3 + 13;
    }

    if (pwmm2 > Maxpwm)                                                                    //The pwm should not exceed the desired maximum pwm
      pwmm2 = Maxpwm;

    if (pwmm3 > Maxpwm)
      pwmm3 = Maxpwm;


    digitalWrite(dir1, HIGH);                                                              //Giving appropriate direction for the wheels according to A_Forward direction
    digitalWrite(dir2, LOW);
    digitalWrite(dir3, LOW);

    analogWrite(pwm1, 0);                                                                  //Giving appropriate pwm to the motor driver
    analogWrite(pwm2, abs(pwmm2));
    analogWrite(pwm3, abs(pwmm3));

/********************************************* SERIAL PRINTING DATA ***************************************************/
     /* Serial.print("yaw: ");
      Serial.print(yaw);
      Serial.print("\tYaw: ");
      Serial.print(Yaw);
      Serial.print("\tError: ");
      Serial.print(a_error_forward);
      Serial.print("\tError encoder: ");
      Serial.print(a_error_encoder_forward);
      Serial.print("\tencodervalue2 :      ");
      Serial.print(encodervalue1);
      Serial.print("\tdistance covered :      ");
      Serial.print(a_distanceCovered_forward);
      Serial.print("\tPWM:  ");
      Serial.print(pwmm1);
      Serial.print("   ");
      Serial.print(pwmm2);
      Serial.print("   ");
      Serial.println(pwmm3);*/
  }
  if (a_distanceCovered_forward >= a_requiredDistance_forward)                                  // Stoping the bot after the required distance is reached
  {
    analogWrite(pwm1, 0);
    analogWrite(pwm2, 0);
    analogWrite(pwm3, 0);
    //delay(1000);
  }
  Yaw_ref = Yaw;                                                                            //Setting the reference value for the next function that is called                   
  a_distanceCovered_forward = 0;                                                            //Flushing the value of the variable                                           
}

/*
   Function Name:A_Backward()
   Input:  Required distance(a_requiredDistance_back) for which function is to be executed,Proportionality constants of Each Motors(a_kp_strm1_back,a_kp_strm2_back,a_kp_strm3_back),
           Encoders(a_kp_encoder_back) and Distance constant(a_kp_dist_back,a_ki_dist_back)
   Output: Motor 2 and 3 will move with same pwm and Motor 1 will have zero PWM. Bot will move in ackward Direction(along Motor 1 backward).
   Logic: By giving same PWM to Motors 2 and 3 and Motor 1 will have zero PWM,the bot will move in backward direction. MPU and two XY Encoders are used for FEEDBACK of System.
          PID is implemented for precise movement.
   Example Call:A_Backward(200, a_kp_strm1_back, a_kp_strm2_back, a_kp_strm3_back, a_kp_dist_back, a_kp_encoder_back, a_ki_dist_back);
*/
void A_Backward(float a_requiredDistance_back,float a_kp_strm2_back,float a_kp_strm3_back,float a_kp_dist_back,float a_kp_encoder_back,float a_ki_dist_back)
{
  encodervalue1 = 0;                                                    //Shifting the origin by initializing both the encoder values to zero
  encodervalue2 = 0;
  while (a_distanceCovered_back < a_requiredDistance_back)              //Execute the function till required distance is not reached
    {
    if (Serial3.available())                                            //If data is available on the serial bus
    {
      yaw = Serial3.read();                                             //Read the data on the serial bus and store it in the variable yaw
    }
    Yaw = yaw * 2;                                                      //Convert the range of yaw from -90 to 90 to -180 to 180

    a_error_back = Yaw - Yaw_ref;                                         //Calculate the angular shift of the bot. Yaw_ref is the reference yaw value from the previous function 

    a_current_back = abs(encodervalue1);                                  //Storing the value of the y encoder                                                                          
    a_distanceCovered_back = a_current_back * 0.05026;                    //Multiplying the value of the encoder by the circumference of the dummy wheel     
    a_errorDist_back = a_requiredDistance_back - a_distanceCovered_back;      //Calculating the error in distance                                                   
    a_error_sum_back = a_errorDist_back + a_error_sum_back;                   //Calculating the sum of the errors                                                 
    a_basePwm = abs(a_errorDist_back) * a_kp_dist_back;                       //Calculating the basepwm in proportion with the error                                     

    a_error_encoder_back = encodervalue2;                                 //Error for locomotion in y direction is given by the x encoder  
    a_pwm_encoder_back = a_kp_encoder_back * (a_error_encoder_back);          //Calculating the pwm error                                      

    pwmm2 = a_basePwm - a_kp_strm2_back * (a_error_back) - a_pwm_encoder_back + a_ki_dist_back * (a_error_sum_back);     //Calculating the pwm for motor 2 according to the equations of velocities
    pwmm3 = a_basePwm  + a_kp_strm3_back * (a_error_back) + a_pwm_encoder_back + a_ki_dist_back * (a_error_sum_back);    //Calculating the pwm for motor 3 according to the equations of velocities

  
    if (pwmm2 > Maxpwm)                                                 //The pwm should not exceed the desired maximum pwm
      pwmm2 = Maxpwm;

    if (pwmm3 > Maxpwm)
      pwmm3 = Maxpwm;


    digitalWrite(dir1, HIGH);                                           //Giving appropriate direction for the wheels according to backward direction
    digitalWrite(dir2, HIGH);
    digitalWrite(dir3, HIGH);

    analogWrite(pwm1, 0);                                               //Giving appropriate pwm to the motor driver
    analogWrite(pwm2, abs(pwmm2));
    analogWrite(pwm3, abs(pwmm3));

/********************************************* SERIAL PRINTING DATA ***************************************************/
    /*Serial.print("yaw: ");
    Serial.print(yaw);
    Serial.print("\tYaw: ");
    Serial.print(Yaw);
    Serial.print("\tError: ");
    Serial.print(a_error_back);
    Serial.print("\tError encoder: ");
    Serial.print(a_error_encoder_back);
    Serial.print("\tencodervalue2 :      ");
    Serial.print(encodervalue1);
    Serial.print("\tdistance covered :      ");
    Serial.print(a_distanceCovered_back);
    Serial.print("\tPWM:  ");
    Serial.print(pwmm1);
    Serial.print("   ");
    Serial.print(pwmm2);
    Serial.print("   ");
    Serial.println(pwmm3);*/
  }
  if (a_distanceCovered_back >= a_requiredDistance_back)                    // Stoping the bot after the required distance is reached
  {
    analogWrite(pwm1, 0);
    analogWrite(pwm2, 0);
    analogWrite(pwm3, 0);
  }
  Yaw_ref = Yaw;                                                        //Setting the reference value for the next function that is called         
  a_distanceCovered_back = 0;                                             //Flushing the value of the variable                              
}
#endif
