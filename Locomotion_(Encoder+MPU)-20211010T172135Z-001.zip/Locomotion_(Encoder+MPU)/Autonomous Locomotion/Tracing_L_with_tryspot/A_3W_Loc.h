/*  Authors            : Rohit
 *  Date               : 24/12/19
 *  FileName           : A_3W_Loc.h
 */
#ifndef _A_3W_Loc_h_
#define _A_3W_Loc_h_

#include "A_Variables.h"

/*
  Function Name:left()
  Input:  Required distance(requiredDistance_left) for which function is to be executed,Proportionality constants of Each Motors(a_kpstrm1_left,a_kpstrm2_left,a_kpstrm3_left),
          Encoders(a_kpencoder_left) and Distance constant(a_kpdist_left,a_kidist_left)
  Output: Motor 2 and 3 will move with same pwm and Motor 1 will move with double the pwm of rest two Motors. Bot will move in Left Direction.
  Logic: By giving same PWM to Motors 2 and 3 and giving double PWM to Motor 1,the bot will move in left direction. MPU and two XY Encoders are used for FEEDBACK of System.
         PID is implemented for precise movement.
  Example Call:left(200, a_kpstrm1_left, a_kpstrm2_left, a_kpstrm3_left, a_kpdist_left, a_kpencoder_left, a_kidist_left);
*/
void left(float requiredDistance_left, float a_kpstrm1_left, float a_kpstrm2_left, float a_kpstrm3_left, float a_kpdist_left, float a_kpencoder_left, float a_kidist_left)
{
  encodervalue1 = 0;                                                        //Shifting the origin by initializing both the encoder values to zero
  encodervalue2 = 0;
  while (a_distanceCovered_left < requiredDistance_left)                      //Execute the function till required distance is not reached
  {
    if (Serial3.available())                                                //If data is available on the serial bus
    {
      yaw = Serial3.read();                                                 //Read the data on the serial bus and store it in the variable yaw
    }
    Yaw = yaw * 2;                                                          //Convert the range of yaw from -90 to 90 to -180 to 180

    a_error_left = Yaw - Yaw_ref;                                             //Calculate the angular shift of the bot. Yaw_ref is the reference yaw value from the previous function 

    a_current_left = abs(encodervalue2);                                      //Storing the value of the x encoder 
    a_distanceCovered_left = a_current_left * 0.05026;                          //Multiplying the value of the encoder by the circumference of the dummy wheel
    errorDist_left = requiredDistance_left - a_distanceCovered_left;          //Calculating the error in distance
    a_error_sum_left = errorDist_left + a_error_sum_left;                       //Calculating the sum of the errors
    a_basePwm = abs(errorDist_left) * a_kpdist_left;                           //Calculating the basepwm in proportion with the error

    a_error_encoder_left = encodervalue1;                                     //Error for locomotion in X direction is given by the y encoder
    a_pwm_encoder_left = a_kpencoder_left * (a_error_encoder_left);              //Calculating the pwm error


    pwmm1 = (a_basePwm  - a_kpstrm1_left * (a_error_left) - a_pwm_encoder_left);      //Calculating the pwm for motor 1 according to the equations of velocities
    pwmm2 = (a_basePwm  + a_kpstrm2_left * (a_error_left) + a_pwm_encoder_left) / 2;//Calculating the pwm for motor 2 according to the equations of velocities
    pwmm3 = (a_basePwm  + a_kpstrm3_left * (a_error_left) + a_pwm_encoder_left) / 2;//Calculating the pwm for motor 3 according to the equations of velocities

    if (errorDist_left < 20)                                                 //Implementing ki if error is less than 20
    {
      pwmm1 = pwmm1 + a_kidist_left * (a_error_sum_left);
      pwmm2 = (pwmm2 + a_kidist_left * (a_error_sum_left)) / 2;
      pwmm3 = (pwmm3 + a_kidist_left * (a_error_sum_left)) / 2;
    }

    if (pwmm1 > Maxpwm)                                                      //The pwm should not exceed the desired maximum pwm
      pwmm1 = Maxpwm;

    if (pwmm2 > Maxpwm)
      pwmm2 = Maxpwm / 2;

    if (pwmm3 > Maxpwm)
      pwmm3 = Maxpwm / 2;


    digitalWrite(dir2, 0);                                                   //Giving appropriate direction for the wheels according to left direction
    digitalWrite(dir3, 1);
    digitalWrite(dir1, 0);

    analogWrite(pwm1, abs(pwmm1));                                           //Giving appropriate pwm to the motor driver
    analogWrite(pwm2, abs(pwmm2));
    analogWrite(pwm3, abs(pwmm3));

    /********************************************* SERIAL PRINTING DATA ***************************************************/
    /*Serial.print("yaw: ");
      Serial.print(yaw);
      Serial.print("\tYaw: ");
      Serial.print(Yaw);
      Serial.print("\tError: ");
      Serial.print(a_error_left);
      Serial.print("\tError encoder: ");
      Serial.print(error_encoder_left);
      Serial.print("\tencodervalue2 :      ");
      Serial.print(encodervalue2);
      Serial.print("\tdistance covered :      ");
      Serial.print(distanceCovered_left);
      Serial.print("\tPWM:  ");
      Serial.print(pwmm1);
      Serial.print("   ");
      Serial.print(pwmm2);
      Serial.print("   ");
      Serial.println(pwmm3);
      Serial.print("\tBasepwm: ");
      Serial.print(basePwm);*/
  }
  if (a_distanceCovered_left >= a_requiredDistance_left)                            // Stoping the bot after the required distance is reached
  {
    analogWrite(pwm1, 0);
    analogWrite(pwm2, 0);
    analogWrite(pwm3, 0);
    delay(1000);
  }
  Yaw_ref = Yaw;                                                                //Setting the reference value for the next function that is called
  a_distanceCovered_left = 0;                                                     //Flushing the value of the variable
}
/*
   Function Name:right()
   Input:  Required distance(requiredDistance_right) for which function is to be executed,Proportionality constants of Each Motors(kp_strm1_right,kp_strm2_right,kp_strm3_right),
           Encoders(kp_encoder_right) and Distance constant(kp_dist_right,ki_dist_right)
   Output: Motor 2 and 3 will move with same pwm and Motor 1 will move with double the pwm of rest two Motors. Bot will move in Right Direction.
   Logic: By giving same PWM to Motors 2 and 3 and giving double PWM to Motor 1,the bot will move in right direction. MPU and two XY Encoders are used for FEEDBACK of System.
          PID is implemented for precise movement.
   Example Call:right(200, kp_strm1_right, kp_strm2_right, kp_strm3_right, kp_dist_right, kp_encoder_right, ki_dist_right);
*/
void right(float requiredDistance_right, float kp_strm1_right, float kp_strm2_right, float kp_strm3_right, float kp_dist_right, float kp_encoder_right, float ki_dist_right)
{
  encodervalue1 = 0;                                                             //Shifting the origin by initializing both the encoder values to zero
  encodervalue2 = 0;   
  while (a_distanceCovered_right < a_requiredDistance_right)                         //Execute the function till required distance is not reached
  {   
    if (Serial3.available())                                                     //If data is available on the serial bus
    {   
      yaw = Serial3.read();                                                      //Read the data on the serial bus and store it in the variable 
    }   
    Yaw = yaw * 2;                                                               //Convert the range of yaw from -90 to 90 to -180 to 180

    a_error_right = Yaw - Yaw_ref;                                                 //Calculate the angular shift of the bot. Yaw_ref is the reference yaw value from the previous function

    a_current_right = abs(encodervalue2);                                          //Storing the value of the x encoder
    a_distanceCovered_right = a_current_right * 0.05026;                             //Multiplying the value of the encoder by the circumference of the dummy wheel
    errorDist_right = a_requiredDistance_right - a_distanceCovered_right;            //Calculating the error in distance                                                                   
    a_error_sum_right = errorDist_right + a_error_sum_right;                         //Calculating the sum of the errors
    a_basePwm = abs(errorDist_right) * kp_dist_right;                              //Calculating the basepwm in proportion with the error

    a_error_encoder_right = encodervalue1;                                         //Error for locomotion in X direction is given by the y encoder
    a_pwm_encoder_right = kp_encoder_right * (a_error_encoder_right);                //Calculating the pwm error    

    pwmm1 =  a_basePwm + 5 + kp_strm1_right * (a_error_right) - a_pwm_encoder_right - 15;  //Calculating the pwm for motor 1 according to the equations of velocities
    pwmm2 = (a_basePwm  - kp_strm2_right * (a_error_right) + a_pwm_encoder_right) / 2;     //Calculating the pwm for motor 2 according to the equations of velocities
    pwmm3 = (a_basePwm  - kp_strm3_right * (a_error_right) + a_pwm_encoder_right) / 2;     //Calculating the pwm for motor 3 according to the equations of velocities

    if (errorDist_right < 20)                                           //Implementing ki if error is less than 20
    {
      pwmm1 = pwmm1 + ki_dist_right * (a_error_sum_right);
      pwmm2 = (pwmm2 + ki_dist_right * (a_error_sum_right)) / 2;
      pwmm3 = (pwmm3 + ki_dist_right * (a_error_sum_right)) / 2;
    }

    if (pwmm1 > Maxpwm)                                                 //The pwm should not exceed the desired maximum pwm
      pwmm1 = Maxpwm;

    if (pwmm2 > Maxpwm)
      pwmm2 = Maxpwm / 2;

    if (pwmm3 > Maxpwm)
      pwmm3 = Maxpwm / 2;


    digitalWrite(dir2, 1);                                              //Giving appropriate direction for the wheels according to right direction
    digitalWrite(dir3, 0);
    digitalWrite(dir1, 1);

    analogWrite(pwm1, abs(pwmm1));                                      //Giving appropriate pwm to the motor driver 
    analogWrite(pwm2, abs(pwmm2));
    analogWrite(pwm3, abs(pwmm3));

    /********************************************* SERIAL PRINTING DATA ***************************************************/
    /*Serial.print("yaw: ");
      Serial.print(yaw);
      Serial.print("\tYaw: ");
      Serial.print(Yaw);
      Serial.print("\tError: ");
      Serial.print(a_error_right);
      Serial.print("\tError encoder: ");
      Serial.print(error_encoder_right);
      Serial.print("\tencodervalue2 :      ");
      Serial.print(encodervalue2);
      Serial.print("\tdistance covered :      ");
      Serial.print(distanceCovered_right);
      Serial.print("\tPWM:  ");
      Serial.print(pwmm1);
      Serial.print("   ");
      Serial.print(pwmm2);
      Serial.print("   ");
      Serial.println(pwmm3);
      Serial.print("\tBasepwm: ");
      Serial.print(basePwm);*/
  }
  if (a_distanceCovered_right >= requiredDistance_right)                           // Stoping the bot after the required distance is reached
  {
    analogWrite(pwm1, 0);
    analogWrite(pwm2, 0);
    analogWrite(pwm3, 0);
    delay(1000);
  }

  Yaw_ref = Yaw;                                                                //Setting the reference value for the next function that is called

  a_distanceCovered_right = 0;                                                    //Flushing the value of the variable
}
/*
   Function Name:updateEncoder1()
   Input: No input required
   Output: pulses of the x encpder stored in variable encodervalue1
   Logic: The function will be called when the interrupt is triggered at the rising edge of channel A.
          If the channel B is in phase with the channel A the count is incremented and decremented otherwise
   Example Call:The function is called by the interrupt
*/
void updateEncoder1()
{
  a = digitalRead(encoderPin1);
  b = digitalRead(comparePinB);

  if (b == 1)encodervalue1++;
  if (b == 0)encodervalue1--;
}

/*
   Function Name:updateEncoder2()
   Input: No input required
   Output: pulses of the y encpder stored in variable encodervalue2
   Logic: The function will be called when the interrupt is triggered at the rising edge of channel A.
          If the channel B is in phase with the channel A the count is incremented and decremented otherwise
   Example Call:The function is called by the interrupt
*/
void updateEncoder2()
{
  c = digitalRead(comparePinA);
  d = digitalRead(encoderPin2);

  if (c == 1)encodervalue2++;
  if (c == 0)encodervalue2--;
}
#endif