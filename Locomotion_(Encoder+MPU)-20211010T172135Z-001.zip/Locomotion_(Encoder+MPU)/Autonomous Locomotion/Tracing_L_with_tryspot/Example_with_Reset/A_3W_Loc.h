/*  Authors             : Rohit
 *  Date                : 24/12/19
 *  FileName            : A_3W_Loc.h
 */
#ifndef _A_3W_Loc_h_
#define _A_3W_Loc_h_

#include "A_Variables.h"

/*
 *  Function Name       : A_Left()
 *  Input               : Required distance(requiredDistance_left) for which function is to be executed,Proportionality constants of Each Motors(a_kpstrm1_left,a_kpstrm2_left,a_kpstrm3_left),
 *                        Encoders(a_kpencoder_left) and Distance constant(a_kpdist_left,a_kidist_left)
 *  Output              : Motor 2 and 3 will move with same pwm and Motor 1 will move with double the pwm of rest two Motors. Bot will move in Left Direction.
 *  Logic               : By giving same PWM to Motors 2 and 3 and giving double PWM to Motor 1,the bot will move in left direction. MPU and two XY Encoders are used for FEEDBACK of System.
 *                        PID is implemented for precise movement.
 *  Example Call        : A_Left(200, a_kpstrm1_left, a_kpstrm2_left, a_kpstrm3_left, a_kpdist_left, a_kpencoder_left, a_kidist_left);
 */
void A_Left(float a_requiredDistance_left, float a_kpstrm1_left, float a_kpstrm2_left, float a_kpstrm3_left, float a_kpdist_left, float a_kp1encoder_left, float a_kp2encoder_left, float a_kp3encoder_left, float a_kidist_left , float a_kd2_dist_left, float a_kd1_dist_left, float a_kd3_dist_left)
{
  encodervalue1 = 0;                                                                        //Shifting the origin by initializing both the encoder values to zero
  encodervalue2 = 0;            
  a_prev_error_left = a_requiredDistance_left;            
  while (a_distanceCovered_left < a_requiredDistance_left)                                  //Execute the function till required distance is not reached
  {           
    if (Serial3.available())                                                                //If data is available on the serial bus
    {           
      yaw = Serial3.read();                                                                 //Read the data on the serial bus and store it in the variable yaw
    }           
    Yaw = yaw * (180.00 / 127.00);                                                          //Convert the range of yaw from -90 to 90 to -180 to 180

    a_error_left = Yaw;                                                                     //Calculate the angular shift of the bot. Yaw_ref is the reference yaw value from the previous function

    a_current_left = abs(encodervalue2);                                                    //Storing the value of the x encoder
    a_distanceCovered_left = a_current_left * 0.05236;                                      //Multiplying the value of the encoder by the circumference of the dummy wheel
    a_errorDist_left = a_requiredDistance_left - a_distanceCovered_left;                    //Calculating the error in distance
    a_error_sum_left = a_errorDist_left + a_error_sum_left;                                 //Calculating the sum of the errors
    a_basePwm = abs(a_errorDist_left) * a_kpdist_left;                                      //Calculating the basepwm in proportion with the error

    a_error_encoder_left = encodervalue1;                                                   //Error for locomotion in X direction is given by the y encoder
    a_pwm_encoder_left1 = a_kp1encoder_left * (a_error_encoder_left);                       //Calculating the pwm error
    a_pwm_encoder_left2 = a_kp2encoder_left * (a_error_encoder_left);                       //Calculating the pwm error
    a_pwm_encoder_left3 = a_kp3encoder_left * (a_error_encoder_left);           

    a_rateChange_left = a_prev_error_left - a_errorDist_left;           


    pwmm1 = (a_basePwm  - a_kpstrm1_left * (a_error_left) + a_pwm_encoder_left1) - 10;      //Calculating the pwm for motor 1 according to the equations of velocities   offset for 400: -20
    pwmm2 = (a_basePwm  + a_kpstrm2_left * (a_error_left) - a_pwm_encoder_left2) / 2 + 15;  //Calculating the pwm for motor 2 according to the equations of velocities   offset for 400: +20
    pwmm3 = (a_basePwm  + a_kpstrm3_left * (a_error_left) - a_pwm_encoder_left3) / 2 ;      //Calculating the pwm for motor 3 according to the equations of velocities   

    if (a_errorDist_left < (a_requiredDistance_left/2.22))                                  //Implementing ki if error is less than 20
    {
      pwmm1 = pwmm1 + a_kidist_left * (a_error_sum_left) + 30;                              //offset for 400: +25      
      pwmm2 = pwmm2 + (a_kidist_left * (a_error_sum_left)) / 2;                        //offset for 400: -25      
      pwmm3 = pwmm3 + (a_kidist_left * (a_error_sum_left)) / 2;


      //a_kpstrm1_left += 0.007;
      //a_kpstrm3_left -= 0.2;
    }

    //If Error is less than One Ninth of the Total Distance than apply D
    if (a_errorDist_left < (a_requiredDistance_left / 10.00))
    {
      pwmm1 -= (a_kd1_dist_left * a_rateChange_left);
      pwmm2 -= (a_kd2_dist_left * a_rateChange_left);
      pwmm3 -= (a_kd3_dist_left * a_rateChange_left);
    }

    if(pwmm1 < 0 || pwmm2 < 0 || pwmm3 < 0)
    {
      pwmm1 = 0;
      pwmm2 = 0;
      pwmm3 = 0;
    }

    if (pwmm1 > Maxpwm)                                                                    //The pwm should not exceed the desired maximum pwm
      pwmm1 = Maxpwm;              
              
    if (pwmm2 > Maxpwm / 2)              
      pwmm2 = Maxpwm / 2;              
              
    if (pwmm3 > Maxpwm / 2)              
      pwmm3 = Maxpwm / 2;              
              
              
    digitalWrite(dir2, 0);                                                                 //Giving appropriate direction for the wheels according to left direction
    digitalWrite(dir3, 1);               
    digitalWrite(dir1, 0);               
              
    analogWrite(pwm1, abs(pwmm1));                                                         //Giving appropriate pwm to the motor driver
    analogWrite(pwm2, abs(pwmm2));
    analogWrite(pwm3, abs(pwmm3));

    /********************************************* SERIAL PRINTING DATA ***************************************************/
    
      Serial.print("yaw: ");
      Serial.print(yaw);
      Serial.print("\tYaw: ");
      Serial.print(Yaw);
      Serial.print("\tError: ");
      Serial.print(a_error_left);
      Serial.print("\tError encoder: ");
      Serial.print(a_error_encoder_left);
      Serial.print("\tencodervalue2 :      ");
      Serial.print(encodervalue2);
      Serial.print("\tdistance covered :      ");
      Serial.print(a_distanceCovered_left);
      Serial.print("\tPWM:  ");
      Serial.print(pwmm1);
      Serial.print("   ");
      Serial.print(pwmm2);
      Serial.print("   ");
      Serial.println(pwmm3);
      Serial.print("\tBasepwm: ");
      Serial.print(a_basePwm);
      a_prev_error_left = a_errorDist_left;
    
  }
  if (a_distanceCovered_left >= a_requiredDistance_left)                                     // Stoping the bot after the required distance is reached
  {
    analogWrite(pwm1, 0);
    analogWrite(pwm2, 0);
    analogWrite(pwm3, 0);
    delay(1000);
  }
  //Setting the reference value for the next function that is called
  a_distanceCovered_left = 0;                                                                //Flushing the value of the variable
}
/*
 *   Function Name      : A_Right()
 *   Input              : Required distance(requiredDistance_right) for which function is to be executed,Proportionality constants of Each Motors(kp_strm1_right,kp_strm2_right,kp_strm3_right),
 *                        Encoders(kp_encoder_right) and Distance constant(kp_dist_right,ki_dist_right)
 *   Output             : Motor 2 and 3 will move with same pwm and Motor 1 will move with double the pwm of rest two Motors. Bot will move in Right Direction.
 *   Logic              : By giving same PWM to Motors 2 and 3 and giving double PWM to Motor 1,the bot will move in right direction. MPU and two XY Encoders are used for FEEDBACK of System.
 *                        PID is implemented for precise movement.
 *   Example Call       : A_Right(200, kp_strm1_right, kp_strm2_right, kp_strm3_right, kp_dist_right, kp_encoder_right, ki_dist_right);
 */
void A_Right(float a_requiredDistance_right, float kp_strm1_right, float kp_strm2_right, float kp_strm3_right, float kp_dist_right, float kp_encoder_right, float ki_dist_right)
{
  encodervalue1 = 0;                                                                          //Shifting the origin by initializing both the encoder values to zero
  encodervalue2 = 0;          
  while (a_distanceCovered_right < a_requiredDistance_right)                                  //Execute the function till required distance is not reached
  {         
    if (Serial3.available())                                                                  //If data is available on the serial bus
    {         
      yaw = Serial3.read();                                                                   //Read the data on the serial bus and store it in the variable
    }         
    Yaw = yaw * 2;                                                                            //Convert the range of yaw from -90 to 90 to -180 to 180

    a_error_right = Yaw;                                                                      //Calculate the angular shift of the bot. Yaw_ref is the reference yaw value from the previous function

    a_current_right = abs(encodervalue2);                                                     //Storing the value of the x encoder
    a_distanceCovered_right = a_current_right * 0.05026;                                      //Multiplying the value of the encoder by the circumference of the dummy wheel
    a_errorDist_right = a_requiredDistance_right - a_distanceCovered_right;                   //Calculating the error in distance
    a_error_sum_right = a_errorDist_right + a_error_sum_right;                                //Calculating the sum of the errors
    a_basePwm = abs(a_errorDist_right) * kp_dist_right;                                       //Calculating the basepwm in proportion with the error

    a_error_encoder_right = encodervalue1;                                                    //Error for locomotion in X direction is given by the y encoder
    a_pwm_encoder_right = kp_encoder_right * (a_error_encoder_right);                         //Calculating the pwm error

    pwmm1 =  a_basePwm + kp_strm1_right * (a_error_right) - a_pwm_encoder_right - 7;          //Calculating the pwm for motor 1 according to the equations of velocities
    pwmm2 = (a_basePwm  - kp_strm2_right * (a_error_right) + a_pwm_encoder_right) / 2 + 10;   //Calculating the pwm for motor 2 according to the equations of velocities
    pwmm3 = (a_basePwm  - kp_strm3_right * (a_error_right) + a_pwm_encoder_right) / 2 + 10;   //Calculating the pwm for motor 3 according to the equations of velocities

    if (a_errorDist_right < 25)                                                               //Implementing ki if error is less than 20
    {
      pwmm1 = pwmm1 + a_ki_dist_right * (a_error_sum_right) - 7;
      pwmm2 = pwmm2 + (a_ki_dist_right * (a_error_sum_right)) / 2 + 10;
      pwmm3 = pwmm3 + (a_ki_dist_right * (a_error_sum_right)) / 2 + 10;
    }

    if (pwmm1 > Maxpwm)                                                                       //The pwm should not exceed the desired maximum pwm
      pwmm1 = Maxpwm;

    if (pwmm2 > Maxpwm / 2)
      pwmm2 = Maxpwm / 2;

    if (pwmm3 > Maxpwm / 2)
      pwmm3 = Maxpwm / 2;


    digitalWrite(dir2, 1);                                                                    //Giving appropriate direction for the wheels according to right direction
    digitalWrite(dir3, 0);                      
    digitalWrite(dir1, 1);                      

    analogWrite(pwm1, abs(pwmm1));                                                            //Giving appropriate pwm to the motor driver
    analogWrite(pwm2, abs(pwmm2));
    analogWrite(pwm3, abs(pwmm3));

    /********************************************* SERIAL PRINTING DATA ***************************************************/
    /*
      Serial.print("yaw: ");
      Serial.print(yaw);
      Serial.print("\tYaw: ");
      Serial.print(Yaw);
      Serial.print("\tError: ");
      Serial.print(a_error_right);
      Serial.print("\tError encoder: ");
      Serial.print(a_error_encoder_right);
      Serial.print("\tencodervalue2 :      ");
      Serial.print(encodervalue2);
      Serial.print("\tdistance covered :      ");
      Serial.print(a_distanceCovered_right);
      Serial.print("\tPWM:  ");
      Serial.print(pwmm1);
      Serial.print("   ");
      Serial.print(pwmm2);
      Serial.print("   ");
      Serial.println(pwmm3);
      Serial.print("\tBasepwm: ");
      Serial.print(a_basePwm);
    */
  }
  if (a_distanceCovered_right >= a_requiredDistance_right)                                    // Stoping the bot after the required distance is reached
  {       
    analogWrite(pwm1, 0);       
    analogWrite(pwm2, 0);       
    analogWrite(pwm3, 0);       
    delay(1000);        
  }       
  //Setting the reference value for the next function that is called        

  a_distanceCovered_right = 0;                                                                //Flushing the value of the variable
}

#endif
