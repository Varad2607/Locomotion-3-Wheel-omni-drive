/*  Authors          : Shivangi, Amogh, Rohit
 *  Date             : 23/12/19
 *  FileName         : M_Variables.h
 */
#ifndef _M_Variables_H_
#define _M_Variables_H_

/***************************************************************************************************************************/
/********************************************* Start of Common Variables ***************************************************/
/***************************************************************************************************************************/

/********** Direction pins **********/
#define dir1 34                              //Direction pin for motor1
#define dir3 30                              //Direction pin for motor3
#define dir2 28                              //Direction pin for motor2
/********** Direction pins **********/

/************* PWM pins *************/
#define pwm1 9                               //PWM pin for motor1
#define pwm3 7                               //PWM pin for motor3
#define pwm2 6                               //PWM pin for motor2
/************* PWM pins *************/

/************ PWM Values ************/
//#define Maxpwm 150.00
//#define basePwm 100
//int pwmm1, pwmm2, pwmm3;
/************ PWM Values ************/

/********* Values of Yaw from MPU6050 *********/
//int8_t yaw = 0;                              // yaw values from MPU6050 using Serial Communications
//int Yaw = 0;                                 //Variable to store the resolved value of yaw from -180 to 180

/********* Values of Yaw from MPU6050 *********/

/***************************************************************************************************************************/
/********************************************** End of Common Variables ****************************************************/
/***************************************************************************************************************************/

/*****************************************************************************************************************************************/
/********************************************* Start of Variables From M_2W_Loc.h File ***************************************************/
/*****************************************************************************************************************************************/

/******* Variables for the encoder *******/
//volatile int encodervalue1, encodervalue2;   // Count of pulses from encoder 1 and encoder 2
//volatile int a, b, c, d;
/******* Variables for the encoder *******/

/************ Encoder Pins ************/
/*#define encoderPin1 2                        //Interupt pin (A channel) for encoder1
#define encoderPin2 21                       //Interrupt pin (A channel) for encoder2
#define comparePinA 50                       // comparepin B channel for encoder1
#define comparePinB 52                      //comparepin B channel for encoder2
/************ Encoder Pins ************/

/*** M_Forward() Function Variables ***/
float error_forward;                         //Variable to store the value of the X encoder as error.
#define kp_encoder_forward 0.04              //Proportionality constant for the lateral error
#define kp_strm2_forward 0.48                //Proportionality constant for the angular error for motor 2
#define kp_strm3_forward 0.48                //Proportionality constant for the angular error for motor 3

float error_encoder_forward;
float pwm_encoder_forward;
float error_sum_forward;
/*** M_Forward() Function Variables ***/

/*** M_Backward() Function Variables ***/
float error_back;
#define kp_encoder_back 0.0625
#define kp_strm2_back 0.25
#define kp_strm3_back 0.25

float error_encoder_back;
float pwm_encoder_back;
float error_sum_back;
/*** M_Backward() Function Variables ***/

/*****************************************************************************************************************************************/
/********************************************** End of Variables From M_2W_Loc.h File ****************************************************/
/*****************************************************************************************************************************************/

/*****************************************************************************************************************************************/
/********************************************* Start of Variables From M_3W_Loc.h File ***************************************************/
/*****************************************************************************************************************************************/

/***** M_Left() Function Variables *****/
float error_left;                             //Variable to store the value of the X encoder as error.
#define kp_encoder_left 0.01
#define kp_strm1_left 0.4
#define kp_strm2_left 0.6
#define kp_strm3_left 0.6

float error_encoder_left;
float pwm_encoder_left;
float error_sum_left;
/***** M_Left() Function Variables *****/

/***** M_Right() Function Variables *****/
float error_right;
#define kp_encoder_right 0.01
#define kp_strm1_right 0.4
#define kp_strm2_right 0.4
#define kp_strm3_right 0.45

float error_encoder_right;
float pwm_encoder_right;
float error_sum_right;
/***** M_Right() Function Variables *****/

/*****************************************************************************************************************************************/
/********************************************** End of Variables From M_3W_Loc.h File ****************************************************/
/*****************************************************************************************************************************************/

/*********************************************************************************************************************************************/
/********************************************* Start of Variables From M_Orient_Loc.h File ***************************************************/
/*********************************************************************************************************************************************/

//Boolean Variables to set direction of Wheels
bool dirW1;
bool dirW2;
bool dirW3;

//PWM Given to motors for rotating
float pwmm_ori;

//PWM Values given to each wheel
int pwmm_ori1, pwmm_ori2, pwmm_ori3;

//Variables used for PID
float req_angle = 0.0;
float error_ang = 3;

//Variables required to keep track of future and past
float rate_change = 5;
float error_sum_ori;
float prev_error = 0;

//PID Constants
#define kp_ori 2.2
#define ki_ang 0.001

/*********************************************************************************************************************************************/
/********************************************** End of Variables From M_Orient_Loc.h File ****************************************************/
/*********************************************************************************************************************************************/

#endif
