/*  Authors             : Amogh
 *  Date                : 24/12/19
 *  FileName            : M_Orient_Loc.h
 */
#ifndef _M_Orient_Loc_h_
#define _M_Orient_Loc_h_

#include "M_Variables.h"
#include "A_Variables.h"

/*
 *  Function Name       : M_TurnTillPressed()
 *  Input               : Required angle(req_ang) for which function is to be executed and  Proportionality constants(KP_Orient, KI_Angle)
 *  Output              : Bot orients as per given required angle(req_angle).
 *  Logic               : Bot orients at desired or required angle from initial position, all motors are given equal pwm until it acquires desired angle.
 *  Example Call        : M_TurnTillPressed(1);
 */
void M_TurnTillPressed(int dir)
{
    if (dir == 1)
    {
        dirW1 = 1;
        dirW2 = 0;
        dirW3 = 1;
    }
    else if (dir == 0)
    {
        dirW1 = 0;
        dirW2 = 1;
        dirW3 = 0;
    }

    pwmm_ori = 50;

    digitalWrite(dir1, dirW1);
    digitalWrite(dir2, dirW2);
    digitalWrite(dir3, dirW3);

    /********************************************* SERIAL PRINTING DATA ***************************************************/
     
        Serial.print("Yaw: ");
        Serial.print(Yaw);
        Serial.print("\tError: ");
        Serial.print(error_ang);
        Serial.print("\tKp:  ");
        Serial.print(kp_ori);
        Serial.print("\tPWM:  ");
        Serial.print(pwmm_ori);
        Serial.print("\trate:  ");
        Serial.println(rate_change);
        Serial.print("\tprevious:  ");
        Serial.println(prev_error);
    

    pwmm_ori1 = pwmm_ori;
    pwmm_ori2 = pwmm_ori;
    pwmm_ori3 = pwmm_ori;

    analogWrite(pwm1, pwmm_ori1);
    analogWrite(pwm2, pwmm_ori2);
    analogWrite(pwm3, pwmm_ori3);
}

/*
 *  Function Name       : M_Turn()
 *  Input               : Required angle(req_ang) for which function is to be executed and  Proportionality constants(KP_Orient, KI_Angle)
 *  Output              : Bot orients as per given required angle(req_angle).
 *  Logic               : Bot orients at desired or required angle from initial position, all motors are given equal pwm until it acquires desired angle.
 *  Example Call        : M_Turn(KP_Orient, KI_Angle, 338.00);
 */
void M_Turn(float KP_Orient, float KI_Angle, float req_angle, int dir)
{
    error_ang = 5;
    while (rate_change != 0 || abs(error_ang) > 2)
    {
        // read from port 1, send to port 0:
        if (Serial3.available())
        {
            yaw = Serial3.read();
        }
        Yaw = yaw * (180.00/127.00);
        
        final_ang  = pow(-1,dir)* req_angle + Shifted_Yaw ;
        final_ang += ((final_ang < -180) - (final_ang > 180))* 360 ;
        
        error_ang = final_ang - Yaw ; 
        error_ang += ((error_ang < -180) - (error_ang > 180))* 360 ;

      
        if (dir)
        {
            dirW1 = 1;
            dirW2 = 0;
            dirW3 = 1;
        }
        else 
        {
            dirW1 = 0;
            dirW2 = 1;
            dirW3 = 0;
        }

        error_sum_ori = error_sum_ori + error_ang;

        if ((prev_error * error_ang) < 0)
        {
            dirW1 = !(dirW1);
            dirW2 = !(dirW2);
            dirW3 = !(dirW3);
        }

        pwmm_ori = abs(error_ang) * KP_Orient;

        if (abs(error_ang) < 20)
        {
            pwmm_ori += (KI_Angle * error_sum_ori);
        }

        rate_change = abs(error_ang) - abs(prev_error);

        if (pwmm_ori > (Maxpwm / 3))
            pwmm_ori = (Maxpwm / 3);

        digitalWrite(dir1, dirW1);
        digitalWrite(dir2, dirW2);
        digitalWrite(dir3, dirW3);

        /********************************************* SERIAL PRINTING DATA ***************************************************/
        
            /*Serial.print("\tYaw: ");
            Serial.print(Yaw);
            Serial.print("\tError: ");
            Serial.print(error_ang);
            Serial.print("\tFinal: ");
            Serial.print(final_ang);
            Serial.print("\tKp:  ");
            Serial.print(KP_Orient);
            Serial.print("\tPWM:  ");
            Serial.print(pwmm_ori);
            Serial.print("\trate:  ");
            Serial.print(rate_change);
            Serial.print("\tprevious:  ");
            Serial.print(prev_error);
            Serial.print("\tdir:  ");
            Serial.println(dir);
        */

        pwmm_ori1 = pwmm_ori;
        pwmm_ori2 = pwmm_ori;
        pwmm_ori3 = pwmm_ori;

        analogWrite(pwm1, pwmm_ori1);
        analogWrite(pwm2, pwmm_ori2);
        analogWrite(pwm3, pwmm_ori3);

        prev_error = error_ang;
    }
    analogWrite(pwm1, 0);
    analogWrite(pwm2, 0);
    analogWrite(pwm3, 0);
   


}

void self_orient( float Yaw_ref)
{ 
  int self_orient_dir;
  correction_angle = Yaw_ref - Shifted_Yaw ;
  M_Turn(0.8, 0.00001,correction_angle, (correction_angle > 0));
  
}
  
  

#endif
